
public class First {
    public static void main(String[] args) {
        System.out.println("I am the Recursion...");
        main(null);
    }
}
