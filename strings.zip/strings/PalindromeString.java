public class PalindromeString {
    public static void main(String[] args) {
        String name = "amit";
        // 2 Pointer
        int i = 0;
        int j = name.length() - 1;

        while (i < j) {
            if (name.charAt(i) != name.charAt(j)) {
                System.out.println("Not a Palindrome String...");
                return;
            }
            i++;
            j--;
        }
        System.out.println("Palindrome String...");

        // String name = "nitin";

        // StringBuilder sb = new StringBuilder(name);
        // sb.reverse();
        // // System.out.println(sb);
        // // System.out.println(name);
        // System.out.println(sb.toString().equals(name)
        // ? "Palindrome String"
        // : "Not a Palindrome String");
    }
}
