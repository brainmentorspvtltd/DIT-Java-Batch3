
public class StringBufferDemo {
    public static void main(String[] args) {
        String name = "Amit";
        name = name + " Srivastava";
        // StringBuffer sb = new StringBuffer("amit");
        StringBuilder sb = new StringBuilder("amit");
        System.out.println(sb.length()); // 4
        System.out.println(sb.capacity()); // 16 + 4 = 20
        sb.append(" lljljkl fghfghghghf hfghgfhfg htfghfghfgh hfgfghfg hgfhfgh hfghfgh");
        System.out.println(sb.length());
        System.out.println(sb.capacity());
        sb.append("jgfdlkgd"); // add at end
        sb.insert(1, "a"); // add at index
        sb.reverse();
        sb.delete(2, 5); // Multi Char delete
        sb.deleteCharAt(1); // single char delete

        System.out.println(sb.length());
        System.out.println(sb.capacity());

        // New cap= Old Cap * sizeOfOneChar + LastChar
        // = 20 * 2 + 2

    }
}
