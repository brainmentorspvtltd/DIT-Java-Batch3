
public class Intro {
    public static void main(String[] args) {
        String name = "Amit".intern();
        String name2 = new String("Amit").intern();
        String name3 = "Amit".intern();
        System.out.println(name == name2);
        System.out.println(name.equals(name2));
        System.out.println("RAM".equals("ram")); // false
        System.out.println("RAM".equalsIgnoreCase("ram")); // true
        System.out.println("Ram".compareTo("Amit")); // Positive Value
        System.out.println("Amit".compareTo("Ram")); // Negative
        System.out.println("Amit".compareTo("Amit")); // 0
        System.out.println(name == name3);
        System.out.println("Amit".charAt(0)); // single character
    }
}
