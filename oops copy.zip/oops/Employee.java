// Encapsulation - Binding Data (Variable) + Methods (Fn) into a Single Unit and this unit is called class.
// Good Encapsulation - Private Data + Public Methods

// Class Access modifier
// Class can be default scope
// Class can be public scope - Can Access outside the package
// if class is public scope - so it class name must be same as file name
public class Employee { // Pascal Case, Noun
    // Members
    // Instance Variables - They Come in memory when u create an instance of an
    // object.
    // Access modifier
    // 1. private - with in the class access
    // 2. default (Assume) - By Default Scope Class Members , This is with in the
    // package scope.
    // 4. public - access with in the package (folder) and also access outside the
    // package
    // Data Hide
    private int id;
    private String name;
    private double salary;
    private String phone;
    private String city;
    private String email;
    private String manager;
    private String pincode;
    private String deptName;
    private final String COMPANY_NAME;
    // private final String COMPANY_NAME = "Brain Mentors"; // ALL CAPS in Constant
    // private double basicSalary; // camelCase

    /*
     * Every class has Default Constructor by Default and it is empty, If u create
     * Param Cons so default (By Default) is killed.
     * Constructor name is same as class name
     * Constructor use to initalize the instance variables
     * When object is created using new so Constructor is invoke
     * Constructor is void by default so it return nothing, dont specify void in
     * constructor, if u specify void so it is become a function.
     */
    // Scope of this constructor (default scope - Package level scope)
    private Employee() {
        // System.out.println("Emp Default Cons");
        id = 0;
        name = "";
        salary = 0.0;
        COMPANY_NAME = "Brain Mentors";
    }

    void Employee() {
        System.out.println("I am a Method not a constructor");

    }

    private Employee(int id, String name) {
        this(); // call Default constructor
        // System.out.println("I am 2 Param Cons");
        this.id = id + COMPANY_NAME.length();
        this.name = name;
    }

    // Parameterized Constructor - Constructor Overloading
    // Constructor Chaining - One Constructor is calling another constructor
    public Employee(int id, String name, double salary) {
        // Always First line constructor call
        this(id, name); // Calling 2 Param Constructor
        // this(); // Constructor Call, We are calling our own class Constructor
        // (Default
        // Constructor No Args)
        // Employee(); // Method Call, Not Constructor call
        // System.out.println("Emp 3 Param Cons Call");
        // this.id = id + COMPANY_NAME.length();
        // this.name = name;
        this.salary = salary;

        // COMPANY_NAME = "Brain Mentors";
    }

    public double hra() {
        return salary * 0.50;
    }

    public double da() {
        return salary * 0.15;

    }

    public double ta() {
        return salary * 0.20;

    }

    public double ma() {
        return salary * 0.15;

    }

    public double pf() {
        return salary * 0.05;

    }

    public double gs() {
        return salary + hra() + da() + ta() + ma() + pf();
    }

    public double tax() {
        double gross = gs();
        if (gross >= 900000) {
            return 0.30;
        } else if (gross < 900000 && gross >= 700000) {
            return 0.20;
        } else if (gross < 700000 && gross >= 500000) {
            return 0.10;
        } else {
            return 0.0;
        }
    }

    public double ns() {
        double tax = gs() * tax();
        return gs() - tax - pf();
    }

    public int getId() {
        return this.id;
    }

    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return this.phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCity() {
        return this.city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getEmail() {
        return this.email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getManager() {
        return this.manager;
    }

    public void setManager(String manager) {
        this.manager = manager;
    }

    public String getPincode() {
        return this.pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getDeptName() {
        return this.deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getCOMPANY_NAME() {
        return this.COMPANY_NAME;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getSalary() {
        return salary;
    }

    // camelCase + verb = method
    /*
     * public void takeInput(int id, String name, double salary) { // i, n, s all
     * are local variable - scope with in the
     * // takeInput
     * // Fn.
     * if (id < 0 || salary < 0) {
     * System.out.println("Invalid Data ");
     * return; // exit from the function
     * }
     * // Instance Variables = Local Variables
     * this.id = id; // LookUp - Near By (Local Variable) LocalVar = LocalVar
     * this.name = name;
     * this.salary = salary;
     * }
     */

    public void print() {
        System.out.println("Id " + this.id);
        System.out.println("Name " + name);
        System.out.println("Salary " + salary);
        System.out.println("Company Name " + COMPANY_NAME);
        System.out.println("***************************************************");
    }

}
