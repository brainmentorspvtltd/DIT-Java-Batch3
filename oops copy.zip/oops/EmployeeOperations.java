import java.text.DateFormat;
import java.text.NumberFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ResourceBundle;

public class EmployeeOperations {
    private ResourceBundle rb;

    EmployeeOperations() {
        rb = ResourceBundle.getBundle("message", getLocale());
    }

    String properCase(String fullName) {
        String[] list = fullName.split(" ");
        String finalName = "";
        for (String name : list) {
            char singleChar = name.charAt(0);
            String temp = String.valueOf(singleChar).toUpperCase() + name.substring(1).toLowerCase();
            finalName += temp + " ";
        }
        return finalName;
    }

    String readMessageBundle(String key) {

        return rb.getString(key);
    }

    void printSalarySlip(Employee employee) {

        System.out.println(readMessageBundle("COMPANY_NAME") + " " + employee.getCOMPANY_NAME().toUpperCase());
        System.out.println("Date " + convertDateFormat());
        System.out.println(readMessageBundle("EMP_NAME") + " " + properCase(employee.getName()));
        System.out.println(readMessageBundle("EMP_SALARY") + convertCurrencyFormat(employee.getSalary()));
        System.out.println("ALLOWANCES ");
        System.out.println(readMessageBundle("EMP_HRA") + convertCurrencyFormat(employee.hra()));
        System.out.println("DA " + convertCurrencyFormat(employee.da()));
        System.out.println("TA " + convertCurrencyFormat(employee.ta()));
        System.out.println("MA " + convertCurrencyFormat(employee.ma()));
        System.out.println("Deductions ");
        System.out.println("PF " + convertCurrencyFormat(employee.pf()));
        System.out.println("Tax " + convertCurrencyFormat(employee.tax()));
        System.out.println("GS " + convertCurrencyFormat(employee.gs()));
        System.out.println("NS " + convertCurrencyFormat(employee.ns()));

    }

    Locale getLocale() {
        Locale locale = new Locale("fr", "FR");
        return locale;
    }

    String convertDateFormat() {
        Date date = new Date(); // System Date
        DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.FULL, getLocale());
        return dateFormat.format(date);
    }

    String convertCurrencyFormat(double value) {
        // FR - fr
        // US - en

        // Locale locale = new Locale("hi", "IN");
        NumberFormat nf = NumberFormat.getCurrencyInstance(getLocale());
        String formattedValue = nf.format(value);
        return formattedValue;
    }
}
