

public class CountSetBit {
   public static void main(String[] args) {
    int num = 10;
    int countSetBit = 0;
    while(num>0){
        if((num & 1) !=0){
            countSetBit++;
        }
        num = num>>1; // Divide Operation num / 2^1
    }
    System.out.println(countSetBit);
   } 
}
