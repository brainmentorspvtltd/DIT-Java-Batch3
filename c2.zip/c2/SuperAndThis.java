class P{
    int x;
    P(){
        x = 10;
    }
    void show(){
        System.out.println("I am Show of Parent");
    }
}
class C extends P{
    int x;
    C(int x){
        // implicit super call super();
        //int z = this.x + super.x + x;
        //System.out.println("Z is "+z);
    }
    @Override
    void show(){
        super.show();
        System.out.println("I am Show of Child");
    }
}
class C2 extends C{
    int x =2;
    C2(int x){
        super(x);
        int z = this.x + ((P)this).x+ ((C)this).x + x;
        System.out.println(z);
    }

}
public class SuperAndThis {
    public static void main(String[] args) {
        C2 obj = new C2(10);
        obj.show();
    }
}
