class A1{
    int x ;
    
    A1(){
        //this(10);
         x = 10;
        System.out.println("A1 Default Cons "+x);
    }
    A1(int x){
        this(); // Own class Default Cons Call, first line
        this.x = x;
        System.out.println("A1 Param Cons Call "+this.x);
    }
}
class B1 extends A1{
    int y ;
    B1(){
        // Internally Implicit super call - Means calling parent default constructor
        // super();  - Parent Default Cons Call
        // super () - parent class cons call , always place on first line
        // explicit call
        super(2); // Call Parent param cons 
        y = x + 10;
        System.out.println("B1 Default Cons "+y);
    }
    B1(int y){
        this();
        //super(y); // first line
        System.out.println("B1 Param Cons call");
        this.y = this.x  + y;
        System.out.println("b1 Param Cons Call "+this.y);
    }
}
public class ConsChain {
    public static void main(String[] args) {
        B1 obj =new B1(3); // Call Default Cons of B1

    }
}
