// IS - A Inheritance Based (Parent - Child RelationShip)
// 1. Code Reuse
// Java Support single Inheritance in case of classes.
//2. Polymorphism - One thing having several Forms
// e.g roi
/*
abstract class are those classes which is most generic in nature
all the common things are present in generic class
so it is use for inheritance only
we are not going to create the object of generic class because it is become
meaning less.
*/
abstract class Account {
    private int id;
    String name;
    double balance;

    private Account(){
        System.out.println("Account class Default Cons Call");
    }
    Account(int x){
        this(); // Own class Cons call
        System.out.println("Account Class param cons call");
    }
    // void roi() {
    //     System.out.println("Account ROI 2%");
    // }
    // abstract class may have abstract methods
    abstract void roi(); // abstract methods are bodyless methods

    void printBalance() {
        System.out.println("Account Print Balance ");
    }
}

class SavingAccount extends Account {
    int limit;
    SavingAccount(){
        // super();
        super(1);
        System.out.println("SavingAccount Default Cons Call");
    }
    void limitedTrans() {
        System.out.println("Limit of Trans in Saving Account");
    }

    // Overriding Only in case of ISA - When some method comes from the parent and
    // it is outdated for
    // the child, so child override it.
    // During override the parent and child method signature are same.
    // Signature - return type method name args
    @Override // @Override is a Annotation, This tell to the compiler we are
    // doing overriding.
    // When we do overiding so parent feature it is hide.
    void roi() { // Overriding
        // void roi(int x) { // Overloading
        // super - is a keyword , and it hold the reference of parent, so through this
        // we can access parent things.
        //super.roi(); // parent wala roi call
        System.out.println("Account ROI 4% Rec");
    }
}

class CurrentAccount extends Account {
    CurrentAccount(){
        // super();
        super(1);
        System.out.println("CurrentAccount Default Cons Call");
    }
    void odLimit() {
        System.out.println("Overdraft Limit in Current Account");
    }

    void roi() {
        System.out.println("Account ROI 5% Pay");
    }

    void zeroBalance() {
        System.out.println("Make a Zero Balance in Current Account");
    }
}

class FixedDepositAccount extends Account {
    FixedDepositAccount(){
        // super();
        super(1);
        System.out.println("FixedDepositAccount Default Cons Call");
    }
    void lockingPeriod() {
        System.out.println("Locking Period of 2 years");
    }

    void roi() {
        System.out.println("Account ROI 7% Rec");
    }
}

class AccountCaller {
    // Common Kind of Code
    // Polymorphic or Generic Function
    // Upcasting
    void caller(Account account) {
        // Common Fn Call
        account.roi();
        account.printBalance();
        System.out.println("***********************************");
        if (account instanceof SavingAccount) { // Before Cast Check it
            ((SavingAccount) account).limitedTrans(); // Downcasting
        } else if (account instanceof CurrentAccount) {
            CurrentAccount ca = (CurrentAccount) account; // int x = 10; byte w = (byte) x;
            ca.odLimit(); // Call Specific Fn
            ca.zeroBalance();
        } else if (account instanceof FixedDepositAccount) {
            // Downcasting
            ((FixedDepositAccount) account).lockingPeriod();
        }
        // account.limitedTrans();
    }

}

public class ISA {
    public static void main(String[] args) {
        AccountCaller ac = new AccountCaller();
       // ac.caller(new Account());
        ac.caller(new SavingAccount());
        //ac.caller(new CurrentAccount());
        //ac.caller(new FixedDepositAccount());
        // Account account = new SavingAccount(); // Upcasting (Child Object cast to
        // parent)
        // account.roi(); // override version call
        // account.printBalance();
        // //account.limitedTrans(); // Specific to child

        // account = new CurrentAccount(); // Upcasting
        // account.roi();
        // account.printBalance();
        // //account.odLimit();

        /*
         * SavingAccount sa = new SavingAccount();
         * sa.roi(); // Overriding - Child Version
         * // sa.roi(); // Polymorphism - Overloading
         * // sa.roi(2);
         * sa.printBalance(); // Code Reuse (Parent Version)
         * sa.limitedTrans(); // Child
         * System.out.println("***********************");
         * CurrentAccount currentAccount = new CurrentAccount();
         * currentAccount.roi(); // Override
         * currentAccount.printBalance(); // Account
         * currentAccount.odLimit(); // Child
         * currentAccount.zeroBalance(); // Child
         * System.out.println("*********************");
         * FixedDepositAccount fd = new FixedDepositAccount();
         * fd.roi();// Override
         * fd.printBalance(); // Parent
         * fd.lockingPeriod(); // Child
         */
    }

}
