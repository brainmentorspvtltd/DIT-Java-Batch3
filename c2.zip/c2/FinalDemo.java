import java.util.LinkedList;

class X{
    //final int a = 10; // Eager Way
    //final int b = 20;
    final int a; // Lazy way
    final int b;
    X(){
        a = 10;
        b = 20;
    }
    X(int a, int b){
        this(); 
        
       // this.a = a;
       // this.b= b;
    }
}

// with class
final class Math{

}
class A{
    // with method
    final void show(){

    }
}
 class B extends A{
     int f,g;
    // @Override
    // void show(){

    // }
 }



public class FinalDemo {
    public static void main(String[] args) {
        final B obj = new B();
        obj.f++;
        obj.g++;
        //obj = new B();
        // Local Var u can use final
        // with var (Value or Reference)
        final int MAX = 100; // define constant
        final LinkedList<String> linkedList = new LinkedList<>();
        linkedList.add("amit");
        linkedList.add("ram");
        System.out.println(linkedList);
        //linkedList = new LinkedList<>();


        //MAX ++; // ERROR
        //MAX = 200;
    }
}
