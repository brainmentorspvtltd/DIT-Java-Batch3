class P1{
    int x;
    P1(){
        x = 10;
    }
    void show(){
        System.out.println("P1 Show");
    }
}
class C1 extends P1{
    int x;
    C1(){
        x =20;
    }
    @Override
    void show(){
        System.out.println("C1 Show "+(super.x + this.x));
    }
}
public class Bind {
    public static void main(String[] args) {
        //P1 c = new C1(); 
        // Variable bind with type/class
        // Method bind with object
        C1 c =new C1();
        System.out.println(c.x);
        c.show();
    }
}
