package com.brainmentors.chatapp.dao;
// Contains the DB CRUD Operations
public class UserDAO {

}
