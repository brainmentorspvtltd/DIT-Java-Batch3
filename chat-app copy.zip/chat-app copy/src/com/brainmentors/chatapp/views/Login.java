package com.brainmentors.chatapp.views; // first line

public class Login {

}
