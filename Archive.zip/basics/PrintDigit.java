import java.util.Scanner;

public class PrintDigit {
    public static void main(String[] args) {
        System.out.println("Enter the Number");
        int n = new Scanner(System.in).nextInt();
        int temp = n;
        int count = 0;
        // Count Digit
        while (temp != 0) {
            temp = temp / 10;
            count++;
        }
        int pow = count - 1;
        while (pow >= 0) {
            int deno = (int) Math.pow(10, pow);
            System.out.println(n / deno);
            n = n % deno;
            pow--;
        }

    }
}
