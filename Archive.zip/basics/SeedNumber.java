public class SeedNumber {
    public static void main(String[] args) {
        int n = 123;
        int n2 = 738;
        int temp = n; // Copy
        int result = 1;
        while (temp != 0) {
            int singleDigit = temp % 10;
            result = result * singleDigit;
            temp = temp / 10;
        }
        if ((n * result) == n2) {
            System.out.println("Seed Number");
        } else {
            System.out.println("not a Seed Number");
        }
    }
}
