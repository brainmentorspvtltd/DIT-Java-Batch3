import java.util.Scanner;

public class Input2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the First Number");
        int firstNumber = scanner.nextInt();
        System.out.println("Enter the Second Number");
        int secondNumber = scanner.nextInt(); // 200\n
        System.out.println(firstNumber + secondNumber);
        System.out.println("Enter the Name");
        // String name = scanner.next(); // word
        scanner.nextLine(); // eat above \n
        String name = scanner.nextLine(); // \n line
        System.out.println(name);

        Scanner scanner2 = new Scanner(System.in);
        System.out.println("Enter the First Number");
        firstNumber = scanner2.nextInt();
        System.out.println(firstNumber);
        scanner.close();
        scanner2.close();
    }
}
