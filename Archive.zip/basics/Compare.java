public class Compare {
    public static void main(String[] args) {
        StringBuilder sb = new StringBuilder("Amit");
        StringBuilder sb2 = new StringBuilder("Amit");

        String name = "Akhil";
        String name3 = "Soni";
        String name2 = new String("Ajay");
        // System.out.println(sb.equals(sb2));
        System.out.println(sb.toString().equals(sb2.toString()));
        // System.out.println(sb.compareTo(sb2));
        // System.out.println(name.compareTo(name3));
        System.out.println(name == name2); // Ref Compare
        // equals - we can compare the value give true (same) false not same
        // equalsIgnoreCase - Compare the value but ignore the case (Upper or Lower)
        // true / false
        // compareTo both are same so return 0 > Postitive < Negative

        System.out.println(name.compareTo(name2));
        System.out.println(name2.compareTo(name));
        // if (name.compareTo(name2) == 0) {
        // if(name.equalsIgnoreCase(name2)){
        if (name.equals(name2)) {
            System.out.println("Same");
        } else {
            System.out.println("Not same");
        }
    }
}
