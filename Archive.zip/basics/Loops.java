public class Loops {
    public static void main(String[] args) {
        // Amit 10 times Print
        // for/ while / do while
        // for loop start , end
        // dhoni is captain for 2005 to 2015
        for (int i = 1; i <= 10; i++) {
            System.out.println("Amit " + i);
        }
    }
}
