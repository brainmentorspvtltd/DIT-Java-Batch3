public class Pattern4 {
    public static void main(String[] args) {
        int n = 5;
        for (int row = n; row >= 1; row--) {
            for (int space = n - row; space >= 1; space--) {
                System.out.print(" ");
            }
            for (int star = row; star >= 1; star--) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
