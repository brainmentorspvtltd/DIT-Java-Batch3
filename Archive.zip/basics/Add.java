
public strictfp class Add {
    public static void main(String[] args) {
        int t; // Local Variable Has to be initalize first
        // System.out.println(++t);
        byte q = (byte) 130;
        System.out.println(q);
        boolean att = true;
        char w1 = 'न';
        System.out.println(w1);
        float w = 90.20f;
        double d = 90.3434;
        int a = 1;
        int b = 2;
        int c = a + b;
        System.out.println("Sum is " + c);
    }
}
