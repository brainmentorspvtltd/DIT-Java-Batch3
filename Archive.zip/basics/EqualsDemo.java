public class EqualsDemo {
    public static void main(String[] args) {
        String name = "Amit";
        String name2 = "Amit";
        String name3 = new String("Amit");
        System.out.println(name == name3);
        System.out.println(name.equals(name3));
        System.out.println("amit".equalsIgnoreCase("AMIT"));
        System.out.println("amit".compareTo("ajay"));
        int a = 100;
        int b = 100;
        System.out.println(a == b);

    }
}
