public class Rotate {
    public static void main(String[] args) {
        int n = 12345;
        int temp = n;
        int r = -1;
        int count = 0;
        // Count Digit
        while (temp != 0) {
            temp = temp / 10;
            count++;
        }
        r = r % count; // make it with in the range
        if (r < 0) { // Negative rotation
            r = count + r;
        }
        int pow = count - r;
        int left = n / (int) Math.pow(10, r);
        int right = n % (int) Math.pow(10, r);
        int result = right * (int) Math.pow(10, pow) + left;
        System.out.println(result);

    }
}
