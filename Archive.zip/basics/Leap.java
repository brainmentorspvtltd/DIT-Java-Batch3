import java.util.Scanner;

public class Leap {
    public static void main(String[] args) {
        System.out.println("Enter the Year");
        int year = new Scanner(System.in).nextInt();
        if (year % 4 == 0) { // Every 4 Year
            if (year % 100 == 0) { // Century Year
                if (year % 400 == 0) {
                    System.out.println("Leap Year");
                    return; // exit from the main function
                } else {
                    System.out.println("Not a Leap Year");
                    return;
                }
            }
            System.out.println("Leap Year");
        } else {
            System.out.println("Not a Leap Year");
        }
    }
}
