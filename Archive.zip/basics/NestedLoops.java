public class NestedLoops {
    public static void main(String[] args) {
        outer: for (int i = 1; i <= 3; i++) {
            for (int j = 1; j <= 3; j++) {
                if (i == j) {
                    // break outer; // exit from the given loop
                    // break; // exit from the current loop
                    // continue ; // skip from the current iteration
                    continue outer; // skip from the given label
                } // if ends
                System.out.println(i + " " + j);
            } // inner loop ends
        } // outer loop ends
        System.out.println("Last Line");
    }
}
