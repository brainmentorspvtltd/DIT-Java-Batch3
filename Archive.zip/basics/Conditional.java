public class Conditional {
    public static void main(String[] args) {
        int a = 10;
        int b = 20;

        int day = 1;
        if (day == 1) {
            System.out.println("Working Day");
        } else if (day == 2) {
            System.out.println("Another Working Day");
        } else {
            System.out.println("Wrong Day");
        }
        // if(a>b)
        // System.out.println("A is Greater");
        // System.out.println("hgdfjkghjk");
        if (a > b) {
            System.out.println("A is Greater");
        } else {
            System.out.println("B is Greater");
        }

    }
}
