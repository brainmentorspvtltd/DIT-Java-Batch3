public class SumOfDigitDiv {
    public static void main(String[] args) {
        int n = 123;
        int temp = n;
        int sum = 0;
        while (temp != 0) {
            int singleDigit = temp % 10;
            sum = sum + singleDigit;
            temp = temp / 10;
        }
        System.out.println(n % sum == 0 ? "Yes Divisible" : "No");
    }
}
