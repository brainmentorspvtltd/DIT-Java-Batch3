public class A1 extends Object {
    @Override
    public int hashCode() {
        return 1;
    }

    public static void main(String[] args) {
        A1 obj1 = new A1();
        A1 obj2 = new A1();
        System.out.println(obj1.hashCode());
        System.out.println(obj2.hashCode());
    }
}
