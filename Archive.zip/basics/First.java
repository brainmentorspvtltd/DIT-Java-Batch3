class Second {

    static void main() {
        System.out.println("Hi this is my main fn");
    }

    static public void main(String... arr) {
        // Execution Start Here
        System.out.println("Hello Java");
        // main();
    }
}