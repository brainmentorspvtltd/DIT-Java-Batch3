
public class Kmp {

    static void better(String str, int[] lps) {
        int strLen = str.length();
        int len = 0;
        lps[0] = 0; // first prefix is always prefix , so prefix and suffix not match so length is 0
        int i = 1;// start from 1st index (2nd Char)
        while (i < strLen) {
            char prefix = str.charAt(len); // start 0
            char suffix = str.charAt(i); // next to the length
            if (prefix == suffix) {
                len++;
                lps[i] = len;
                i++; // move to the next char
            } else {
                // prefix not match with suffix
                if (len == 0) {
                    // first char
                    lps[i] = 0; // set 0 length
                    i++; // move to the next character
                } else {
                    len = lps[len - 1]; // move the previous index of lps array which consist of last matching prefix
                                        // length
                }

            }
        }
    }

    public static void main(String[] args) {
        String str = "ababa";
        String pattern = "aba";
        int strLen = str.length();
        int patternLen = pattern.length();
        int lps[] = new int[patternLen];
        better(pattern, lps);
        for (int i : lps) {
            System.out.println(i);
        }
        int i = 0; // i for str
        int j = 0; // j for pattern

        while (i < strLen) {
            if (pattern.charAt(j) == str.charAt(i)) {
                i++;
                j++;
            }
            if (j == patternLen) {

                System.out.println("Pattern Found at Index " + (i - j));
                j = lps[j - 1];
            } else if (i < strLen && pattern.charAt(j) != str.charAt(i)) {
                if (j == 0) { // No more prefix so move to the next char in string
                    i++;
                } else {
                    // move in pattern
                    j = lps[j - 1]; // move to the previous prefix count in array
                }
            }
        }

    }
}
