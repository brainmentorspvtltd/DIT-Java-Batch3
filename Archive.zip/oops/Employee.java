// Encapsulation - Binding Data (Variable) + Methods (Fn) into a Single Unit and this unit is called class.
// Good Encapsulation - Private Data + Public Methods

// Class Access modifier
// Class can be default scope
// Class can be public scope - Can Access outside the package
// if class is public scope - so it class name must be same as file name
public class Employee { // Pascal Case, Noun
    // Members
    // Instance Variables - They Come in memory when u create an instance of an
    // object.
    // Access modifier
    // 1. private - with in the class access
    // 2. default (Assume) - By Default Scope Class Members , This is with in the
    // package scope.
    // 4. public - access with in the package (folder) and also access outside the
    // package
    // Data Hide
    private int id;
    private String name;
    private double salary;
    private final String COMPANY_NAME = "Brain Mentors"; // ALL CAPS in Constant
    // private double basicSalary; // camelCase

    // camelCase + verb = method
    public void takeInput(int id, String name, double salary) { // i, n, s all are local variable - scope with in the
                                                                // takeInput
        // Fn.
        if (id < 0 || salary < 0) {
            System.out.println("Invalid Data ");
            return; // exit from the function
        }
        // Instance Variables = Local Variables
        this.id = id; // LookUp - Near By (Local Variable) LocalVar = LocalVar
        this.name = name;
        this.salary = salary;
    }

    public void print() {
        System.out.println("Id " + this.id);
        System.out.println("Name " + name);
        System.out.println("Salary " + salary);
    }

}
