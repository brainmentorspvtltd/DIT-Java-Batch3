public class TestEmployee {
    public static void main(String[] args) {
        Employee amit; // amit is a reference variable of Employee Type
        amit = new Employee();
        // amit.id = -1001;
        // amit.name = "Amit";
        // amit.salary = -99999;
        // Abstraction - Hide the Details , Just use it
        amit.takeInput(-1001, "Amit", -99999); // we are calling a fn with an object
        // e,g obj.fn()
        // now fn will recieve reference of calling object and special keyword called
        // this.
        amit.print();
        // amit.id = 1001;
        // amit.name = "Amit";
        // amit.salary = 99999;
        // System.out.println("Id " + amit.id);
        // System.out.println("Name " + amit.name);
        // System.out.println("Salary " + amit.salary);
        Employee ram = new Employee();
        ram.takeInput(1002, "Ram", 55555);
        ram.print();
        // ram.id = 1002;
        // ram.name = "Ram";
        // ram.salary = 55555;
        // System.out.println(ram.id);
        // System.out.println(ram.name);
        // System.out.println(ram.salary);
        // new - keyword, Memory Allocate Runtime
        // In this case it is creating a new Memory of Employee
        // When we create a class we create a Custom Data Type.
        // int x; // x is a variable of type int
        // x = 10; // initalize
    }
}
