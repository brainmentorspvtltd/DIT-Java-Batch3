
public class SearchInSubSeq {
    public static void main(String[] args) {
        String str = "abcd";
        String search = "bd";
        int len = str.length();
        int j = 0;
        for (int i = 0; i < len; i++) {
            if (str.charAt(i) == search.charAt(j)) {
                j++;
            }
        }
        System.out.println(j == search.length() ? "Pattern Found..." : "Not Found...");
    }
}
