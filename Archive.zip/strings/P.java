
public class P {
    public static void main(String[] args) {
        String str = "ABCABCBCDABC";
        String pattern = "ABC";
        int n = str.length();
        int p = pattern.length();
        for (int i = 0; i <= (n - p);) {
            int j;
            for (j = 0; j < p; j++) {
                if (pattern.charAt(j) != str.charAt(i + j)) {
                    break;
                }
            }
            if (j == p) {
                System.out.println("Pattern Found" + i);
            }
            if (j == 0) {
                i++;
            } else {
                i = i + j;
            }
        }
    }
}
