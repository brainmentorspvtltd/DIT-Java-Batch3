
public class A {
    public static void main(String[] args) {
        A obj = new A();
        System.out.println(obj.hashCode());
        A obj2 = new A();
        System.out.println(obj2.hashCode());
    }
}
