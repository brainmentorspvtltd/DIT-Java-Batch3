public class CompareIntFloat {
    public static void main(String[] args) {
        long n = 100000;
        long p[] = new long[100000];

        for (int i = 0; i < n; i++) {
            p[i] = 4444444l;
        }
        double w = 9.11112;
        int t = (int) w;
        if (t == w) {
            System.out.println("Same");
        } else {
            System.out.println("Not Same");
        }

    }
}
