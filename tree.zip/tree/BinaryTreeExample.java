import java.util.Scanner;
import java.util.Stack;

class BinaryTree<T> {
    T data;
    BinaryTree<T> left; // Left Child Reference
    BinaryTree<T> right; // right child Reference

    BinaryTree(T data) {
        this.data = data;
        // default left and right are null (Java)
    }
}

class BinaryTreeOperations {
    String msg = "root";
    Scanner scanner = new Scanner(System.in);
    int parent = -1;

    BinaryTree<Integer> insert() {
        System.out.println("Enter the Data for " + msg + " Node and Parent is " + parent + " For Exit Write -1 ");
        int data = scanner.nextInt();
        // Termination case
        if (data == -1) {
            return null;
        }
        // Create a Parent Node / root node
        BinaryTree<Integer> node = new BinaryTree<>(data);
        parent = data;
        msg = "left";
        node.left = insert();
        msg = "right";
        parent = data;
        node.right = insert();
        parent = data;
        msg = "root";
        return node; // return root node

    }

    void print(BinaryTree<Integer> currentNode) {
        // Termination Case
        if (currentNode == null) {
            return;
        }
        String output = "";
        output += currentNode.data + " => ";
        if (currentNode.left != null) {
            output += "Left : " + currentNode.left.data + " , ";
        }
        if (currentNode.right != null) {
            output += "Right : " + currentNode.right.data + " , ";
        }
        System.out.println(output);
        print(currentNode.left);
        print(currentNode.right);

    }

    void preOrder(BinaryTree<Integer> root) {
        // Termination Case
        if (root == null) {
            return;
        }
        // Parent, Left and then Right
        System.out.println(root.data); // Parent Print
        preOrder(root.left); // Small Problem
        preOrder(root.right); // call when stack fall
    }

    void preOrderIterativeSolution(BinaryTree<Integer> root) {
        // Step-0 If root is empty
        if (root == null) {
            return;
        }
        // Step-1 Start with a Stack and push the first node in a Stack
        Stack<BinaryTree> stack = new Stack<>();
        stack.push(root);
        // Step-2 Keep Pop the Element till stack is not empty
        // Pop and Print it.
        // Put the right child first in a stack and then put the left child in a stack
        // the benefit is left is on top .
        // Ensure left is not null and right is not null
        // Step-3 Keep Repeat
        while (!stack.isEmpty()) {
            BinaryTree<Integer> node = stack.pop();
            System.out.println(node.data);
            if (node.right != null) {
                stack.push(node.right);
            }
            if (node.left != null) {
                stack.push(node.left);
            }
        }
    }

    void inOrder(BinaryTree<Integer> root) {
        // Termination Case
        if (root == null) {
            return;
        }
        // Left, Parent and then Right
        inOrder(root.left); // Small Problem
        System.out.println(root.data); // Parent Print

        inOrder(root.right); // call when stack fall
    }

    void inOrderIterative(BinaryTree<Integer> root) {
        // Step-1 Need Stack
        Stack<BinaryTree<Integer>> stack = new Stack<>();
        BinaryTree<Integer> temp = null;
        temp = root;
        while (temp != null || !stack.isEmpty()) {
            while (temp != null) {
                stack.push(temp);
                temp = temp.left;
            }
            temp = stack.pop();
            System.out.println(temp.data);
            temp = temp.right;

        }
    }

    void postOrder(BinaryTree<Integer> root) {
        // Termination Case
        if (root == null) {
            return;
        }
        // Left, Right and then Parent
        postOrder(root.left); // Small Problem
        postOrder(root.right); // call when stack fall
        System.out.println(root.data); // Parent Print

    }
}

public class BinaryTreeExample {
    public static void main(String[] args) {
        BinaryTreeOperations opr = new BinaryTreeOperations();
        BinaryTree<Integer> root = opr.insert();
        opr.print(root);

    }
}
