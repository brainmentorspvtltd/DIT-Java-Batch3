class Person  implements Cloneable{
    String name;
    int id;
    Person(){

    }
    Person(int id , String name){
        this.id = id;
        this.name = name;
    }
    @Override   
    protected Object clone() throws CloneNotSupportedException{
        return super.clone();
    }
}

@FunctionalInterface
// SAM Interface
interface Calculator{
    int compute(int x, int y);
   
}
@FunctionalInterface
interface Calc2 extends Calculator{
    //void show();
}

public class MarkerInterfaceVsFunctionalInterface {
    public static void main(String[] args) throws CloneNotSupportedException {
        
        // Java 8 Lambda Expression
        Calculator calc = (x,y)->x+y;
        System.out.println(calc.compute(10, 20));
        
        Person person = new Person(1001, "Amit");
        //Person person2 = person;
        Person person2 = (Person)person.clone();
        System.out.println("Person " + person.id + " "+person.name);
        System.out.println("Person2 " + person2.id + " "+person2.name);
    }
}
