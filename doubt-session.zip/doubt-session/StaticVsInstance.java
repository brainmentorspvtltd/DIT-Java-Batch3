class User{
    // Members can be Static , can be Instance 
    // Instance Variables - Associate with object , 
    //Becuase when u create an object then instance variables comes in the memory
    String userid; // Scope that is default scope
    String password;
    static int count; // default initalize with 0 
    // static - associate with class
    // static things comes in the memory when we load the class.
    User(String userid, String password){ // Local Variable - Comes in Memory when u call a function or a constructor (Goes in a Stack)
        this.userid = userid;
        this.password = password;
        count++;
    }
    int a;
    // class method / static method only use static things or local variables
    static void show(){
        int  z = 100;
        //a= 20;
        System.out.println("Count is "+count);
    }
    // Non Static / Instance Method - we can static things
     void display(){
        System.out.println("Count is "+count);
    }
}

class StaticVsInstance{
    public static void main(String[] args) {
        User.show();
       User user = new User("amit","1111");
       //user.show();
       User user2 = new User("ram","2222");
        System.out.println(user.userid);
        System.out.println(user.password);
        System.out.println(User.count); // Static Access with ClassName
        // ClassName.staticThing

    }
}