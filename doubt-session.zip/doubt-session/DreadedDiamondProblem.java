
// What to do
interface Player{
    void walk(); // both are abstract methods
    default void jump(){
        System.out.println("Player Jump");
    }
}
interface Power{
    void kick();
    void showHide();
    default void jump(){
        System.out.println("Power Jump");
    }

}
// How to do
class BlackPlayer implements Player, Power{

    @Override
    public void kick() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void showHide() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void walk() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void jump(){
        Player.super.jump();
        Power.super.jump();
        System.out.println("Black Player Jump");
    }

   

}
public class DreadedDiamondProblem {
    public static void main(String[] args) {
        BlackPlayer p = new BlackPlayer();
        p.jump();
    }
}
