// Singleton pattern - It create a single object ,share
// DbConnect , Logger, Formatting
class Connect{
    //private static Connect connect ;  // By Default it is null
    private Connect(){

    }
    // Eager Singleton
    private static Connect connect  = new Connect();
    public static  Connect getInstance(){
        return connect;
    }
    // Lazy Singleton - 
    // Lazy Singleton with MultiThreading - Need a Synchronzed behave
    // Block Level or Method Level 
    // public static  Connect getInstance(){
    //     synchronized(SingleTon.class){
    //     if(connect == null){
    //         connect = new Connect();
    //     }
    // }
    //     return connect;
    // }
}

public class SingleTon {
    public static void main(String[] args) {
        Connect connect = Connect.getInstance();
        Connect connect2 = Connect.getInstance();
        System.out.println(connect == connect2);
        // Connect connect =new Connect();
        // Connect connect2 =new Connect();
        // Connect connect3 =new Connect();
    }
}
