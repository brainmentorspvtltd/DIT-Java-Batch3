class Employee extends Object{
    private int id;
    private String name;
    private double salary;
    // Every class by default has default constrcutor (No Arguments Constructor)
    Employee(){}
    // Paramterized Constructor
    // Initalize Instance Variables
    // For an Object Constructor call only once.
    Employee(int id, String name, double salary){
        this.id = id; // Instance Variable (LHS) = LOCAL Variable (RHS)
        this.name = name;
        this.salary = salary;
       // System.out.println("Constructor Call");
    }
    @Override
    protected void finalize(){
        // Alternative way of Destructor
        //super.finalize();
        id = 0;
        name = null;
        salary = 0.0;
        System.out.println("Finalize Call....");
    }

}
public class ConstructorVsDestructor {
  public static void main(String[] args) {
    //Employee emp = new Employee(); // Object create + Calling a Default Constructor
    Employee emp = new Employee(1001, "Ram",22222);
    // Automatic GC
    emp = null; 
    System.gc(); // Making a Request for GC
    for(int i = 1; i<=10; i++){
        System.out.println("I is "+i);
    }
    
}  
}
