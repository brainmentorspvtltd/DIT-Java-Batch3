class Student implements Cloneable{
    int rollno;
    String name;
    Course course;
    Student(){
        rollno = 10;
        name= "Amit";
        course = new Course();
        
    }
    @Override
    protected Object clone() throws CloneNotSupportedException{
        Course courseObj = (Course)course.clone();
        Student st = (Student)super.clone();
        st.course = courseObj;
        return st;
    }

}
class Course implements Cloneable{
    String name;
    int duration;
    Course(){
        name = "Java";
        duration = 6;
    }
    @Override
    protected Object clone() throws CloneNotSupportedException{
        return super.clone();
    }
}
public class ShallowCopyAndDeepCopy {
   public static void main(String[] args) throws CloneNotSupportedException {
    Student student = new Student();
    Student st2 = (Student)student.clone();
    System.out.println(st2.name +" "+st2.rollno);
    System.out.println(st2.course.name+" "+st2.course.duration);

   } 
}
