// Parent Class
// Abstract class is just a Generic / Common/ Base . 
// It has some common features which is use by Child Classes
// We want to prevent object creation, use just for inheritance
abstract class Account{
    int accountId;
    String name;
    void withDraw(){

    }
    abstract void deposit();
}

// 100% Abstract (WHAT to DO )
abstract interface IAccount{
    int LIMIT = 10; // public static final int LIMIT = 10;
    void withDraw(); // public abstract void withDraw();
    void deposit(); 
    default void roi(){
        System.out.println("ROI");
    }
}
interface B{

}
interface IBank extends IAccount, B{

}
class A{

}

class MyAccount extends A  implements IAccount{

    @Override
    public void withDraw() {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void deposit() {
        // TODO Auto-generated method stub
        
    }
    
}


class SavingAccount extends Account{
    void roiRec(){

    }

    @Override
    void deposit() {
        // TODO Auto-generated method stub
        
    }
}
class CurrentAccount extends Account{
    void roiCharge(){

    }
    void odLimit(){

    }
    @Override
    void deposit() {
        // TODO Auto-generated method stub
        
    }
}
public class AbstractClassVsInterface {
    public static void main(String[] args) {
        SavingAccount sa = new SavingAccount();
        //Account account = new Account();
        System.out.println(IAccount.LIMIT);
    }
}
