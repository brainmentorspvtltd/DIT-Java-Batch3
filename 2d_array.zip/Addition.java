public class Addition {

    public static void main(String[] args) {

     int a[][]={{1,3},{4,2}};
     int b[][]={{2,7},{9,1}};
     int c[][]=new int[2][2];
     int i,j;

     for(i=0;i<2;i++)
     {
         for(j=0;j<2;j++)
         {
             c[i][j]=a[i][j]+b[i][j];
         }
     }

     for(i=0;i<c.length;i++)
     {
         for(j=0;j<c[i].length;j++)
         {
             System.out.print(c[i][j]+" ");
         }

         System.out.println();
     }



    }

}
