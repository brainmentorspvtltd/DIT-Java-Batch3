public class Matrix {

    public static void main(String[] args) {

        int x1[][]=new int[3][3];
        int [][]x2=new int[3][3];
        int []x3[]=new int[3][3];
        int x4[][]=new int[3][];
        x4[0]=new int[10];
        x4[1]=new int[20];
        int x5[][]={{1,2},{3,5}};



    }

}
