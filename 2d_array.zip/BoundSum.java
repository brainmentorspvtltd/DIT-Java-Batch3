public class BoundSum {

    public static void main(String[] args) {

        int arr[][]={{1,2,3},{6,5,3},{2,1,5}};

        int upper=0;
        int lower=0;

        for(int i=0;i<arr.length;i++)
        {
            for(int j=0;j<arr[i].length;j++)
            {
                if(i<=j)
                {
                    upper+=arr[i][j];
                }

                if(j<=i)
                {
                    lower+=arr[i][j];
                }
            }
        }

    System.out.println("Upper Bound sum is "+upper);
    System.out.println("Lower Bound sum is "+lower);

    }

}
