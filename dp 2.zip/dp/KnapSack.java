
public class KnapSack {

    static int knapSack01(int[] weights, int prices[], int maxWeight, int index) {
        // Termination case
        if (index == weights.length || maxWeight == 0) {
            return 0;
        }
        // if current item weight is greater than with given max weight so by pass that
        // item
        if (weights[index] > maxWeight) {
            // By Pass that item
            return knapSack01(weights, prices, maxWeight, index + 1);
        } else {
            // No current item is > maxWeight (Bag)
            // It means item can come in bag
            // Include the item in a Bag (Weight Less) + Value Increase
            int option1 = prices[index] + knapSack01(weights, prices,
                    maxWeight - weights[index], index + 1);
            // Not Include in the Bag
            int option2 = knapSack01(weights, prices,
                    maxWeight, index + 1);
            return Math.max(option1, option2);
        }
    }

    public static void main(String[] args) {
        int maxWeight = 3; // Maximum we have 3 Kg Capacity Bag
        int prices[] = { 60, 100, 120 };
        int weights[] = { 1, 2, 2 };
        int maxProfit = knapSack01(weights, prices, maxWeight, 0);
        System.out.println(maxProfit);

    }
}
