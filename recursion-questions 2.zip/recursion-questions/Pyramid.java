
public class Pyramid {
    static void printSpace(int noOfSpace) {
        // Termination Case
        if (noOfSpace == 0) {
            return;
        }
        System.out.print(" ");
        printSpace(noOfSpace - 1); // Small Problem
    }

    static void printStar(int noOfStar) {
        // Termination Case
        if (noOfStar == 0) {
            return;
        }
        System.out.print("* "); // Processing Logic
        printStar(noOfStar - 1); // Small Problem
    }

    static void prepareRows(int rows, int star) {
        // Termination case
        if (rows == 0) {
            return;
        }
        printSpace(rows - 1);
        printStar(star);
        System.out.println(); // New Line Add
        prepareRows(rows - 1, star + 1); // Small Problem
    }

    public static void main(String[] args) {
        prepareRows(5, 1);
    }
}
