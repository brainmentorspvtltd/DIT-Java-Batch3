import java.lang.Math;
class User{
    // Instance Variables ,  create when object is create
    // Instance Variables per object create
    private String userid;
    private String password;
    // static things will come when class is loaded
    // so static comes eagerly in the memory , it goes
    // when class is unloaded.
    // static things share b/w the objects
    // static things bind with class so it can access with className.staticthing
    private static int count;
    User(String userid, String password){
        this.userid = userid;
        this.password = password;
        count++;
        System.out.println("User Count "+count);
    }
}
final class Validation{
    private Validation(){}
    static boolean isValidPhoneNumber(String phone){
        return phone.length()==10;
    }
    static boolean isValidEmail(String email){
        return email.contains("@");
    }
}
class A{
    static int x,y; // Class Var
    int a,b; // Instance Var
    A(){
        a = 10;
        b= 20;
        System.out.println("I call when object is created....");
    }
    {
        a = 10;
        b= 20;
        System.out.println("Init Block Pre Cons Call");
    }
    {
        System.out.println("Init Block2...");
    }
    static{
        x = 1;
        y = 2;
        System.out.println("I call when class is loaded...");
    }
    static{
        System.out.println("Static Block2....");
    }
}
public class StaticDemo {
    public static void main(String[] args) {
        System.out.println(A.x);
        System.out.println(A.y);
        A obj = new A();
        A obj2 = new A();
        System.out.println(obj.a + " "+obj.b);
        System.out.println(obj2.a + " "+obj2.b);
        // double result = Math.pow(2, 4);
        // //Validation validation = new Validation();
        // System.out.println(Validation.isValidEmail("amit@yahoo.com"));
        // System.out.println(Validation.isValidPhoneNumber("1234567890"));
        /*User user =new User("amit","1111");
        User user2 =new User("ram","1111");
        User user3 =new User("ramesh","1111");*/
    }
}
