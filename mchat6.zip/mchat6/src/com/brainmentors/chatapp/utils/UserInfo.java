package com.brainmentors.chatapp.utils;

public class UserInfo {
	private UserInfo() {}
	public static String USER_NAME ;

}
