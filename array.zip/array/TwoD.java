public class TwoD {
    public static void main(String[] args) {
        int e[][] = new int[3][3];
        int[] r[] = new int[3][3];
        int[][] r2 = new int[3][3];
        int[][] r3 = { { 10, 20 }, { 90, 100 }, { 1000, 2000 } };
        int[][] r4 = new int[3][];
        r4[0] = new int[10];
        r4[1] = new int[20];
        r4[2] = new int[30];

    }
}
